export const hello = "привет"
